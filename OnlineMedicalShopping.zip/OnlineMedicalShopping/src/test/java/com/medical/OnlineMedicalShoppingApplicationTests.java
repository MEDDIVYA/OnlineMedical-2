package com.medical;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OnlineMedicalShoppingApplicationTests {

	@Test
	void contextLoads() {
	}

}
